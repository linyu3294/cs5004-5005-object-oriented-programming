/**
 * Created by vidojemihajlovikj on 8/7/19.
 */
public class DiagonalMove implements IStrategy {
  @Override
  public boolean canMove(int fromx, int fromy, int tox, int toy) {
    return false;
  }

  @Override
  public boolean doMove(int fromx, int fromy, int tox, int toy) {
    return false;
  }
}
