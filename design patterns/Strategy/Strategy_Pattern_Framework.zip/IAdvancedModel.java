/**
 * Created by vidojemihajlovikj on 8/7/19.
 */
public interface IAdvancedModel extends IModel {
  void addStrategy(IStrategy strategy);
}
