/**
 * Created by vidojemihajlovikj on 8/7/19.
 */
public interface IModel {
  void move(int fromx, int fromy, int tox, int toy);
}
