package delegate;

public interface ISoundBehaviour {
  public void makeSound();
}
