package adapter;

public interface IToyDuck {
  public void squeak();
  public String getName();
}
