/**
 * Created by vidojemihajlovikj on 6/5/19.
 */
public interface IContainer {
  void append(int value);
  void remove(int index);
  int pop_front();
  int pop_back();
  void push_front(int value);
  void push_back(int value);
  int getSize();
  int get(int index);
  boolean contains(int value);
  int find(int value);
}
