/**
 * Created by vidojemihajlovikj on 6/5/19.
 */

public class Term{
  int power;
  int coefficient;
}
//public class Node { //same as our node.
//  Term data;
//  Node next;
//  Node previous;
//}
