/**
 * Created by vidojemihajlovikj on 6/5/19.
 */
public class ArrayList implements IContainer {
  int [] myArray;
  int capacity = 5;
  int size = 0;
  public ArrayList(){
    myArray = new int[capacity];
  }

  private void resize(){
    int [] newArray = new int[ capacity * 2];

    for ( int i  =0 ; i < capacity; i++){
      newArray[i] = myArray[i];
    }
    capacity = capacity*2;
    myArray = newArray;

  }

  @Override
  public void append(int value) {
    if ( size == capacity ){
      resize();
    }
    myArray[size] = value;
    size++;
  }

  @Override
  public void remove(int index) {

  }

  @Override
  public int pop_front(){
    return 0;
  }

  @Override
  public int pop_back() {
    if ( size == 0 ){
      throw new IllegalStateException("Trying to pop when size = 0");
    }
    int value = myArray[size-1];
    myArray[size-1] = 0;
    size--;
    return value;
  }

  @Override
  public void push_back(int value){

  }

  @Override
  public void push_front(int value) {
    append(value);
  }

  @Override
  public int getSize() {
    return size;
  }

  @Override
  public int get(int index) throws IllegalStateException {
    if (index < 0 || index >= size){
      throw new IllegalArgumentException("Index out of bounds error.");
    }
    return myArray[index];
  }

  @Override
  public boolean contains(int value) {
    for ( int i = 0; i < size; i++){
      if (  myArray[i] == value ){
        return true;
      }
    }
    return false;
  }

  @Override
  public int find(int value) {
    for ( int i = 0; i < size; i++){
      if (myArray[i] == value){
        return i;
      }
    }
    return -1;
  }

  @Override
  public String toString(){
    String output = "";
    for ( int i = 0; i < size; i++){
      output += myArray[i] + " ";
    }
    return output;
  }
}
