/**
 * Created by vidojemihajlovikj on 6/5/19.
 */





public class LinkedList implements IContainer {
  Node start;
  Node end;

  public LinkedList(){
    this.start = null;
    this.end = null;
  }

  @Override
  public void append(int value) {
    Node newNode = new Node(value);

    if ( start == null && end == null){
      start = newNode;
      end = newNode;
    }else{
      newNode.setPrevious(end);
      end.setNext(newNode);
      end = newNode;
    }
  }

  @Override
  public void remove(int index) {

  }

  @Override
  public int pop_front() {

    return 0;
  }

  @Override
  public int pop_back() {
    Node previous = end.getPrevious();
    previous.setNext(null);
    end.setPrevious(null);
    end = previous;
    return 0;
  }

  @Override
  public void push_front(int value) {

  }

  @Override
  public void push_back(int value) {

  }

  @Override
  public int getSize() {
    return 0;
  }

  @Override
  public int get(int index) {
    return 0;
  }

  @Override
  public boolean contains(int value) {
    return false;
  }

  @Override
  public int find(int value) {
    return 0;
  }
}
