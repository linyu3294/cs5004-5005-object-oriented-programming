/**
 * Created by vidojemihajlovikj on 6/5/19.
 */
public class Main {
  public static void main(String [] args){
   IContainer myArrayList = new ArrayList();

   int random = 0;
   for ( int i = 0 ; i < 161; i++){
     random  = (int)(Math.random()*100 );
     myArrayList.append(random);
   }

   System.out.println(myArrayList);
  }
}
