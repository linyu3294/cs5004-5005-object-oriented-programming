/**
 * Created by vidojemihajlovikj on 6/5/19.
 */
public class Main2 {
  public static void main(String [] args){
  }
}
