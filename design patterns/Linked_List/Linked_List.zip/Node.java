import java.lang.reflect.Array;

/**
 * Created by vidojemihajlovikj on 6/5/19.
 */
public class Node {
  private  int data;
  private Node next;
  private Node previous;

  public Node(int data){
    this.data = data;
    this.next = null;
    this.previous = null;
  }

  void setNext(Node next){
    this.next = next;
  }

  void setPrevious(Node previous){
    this.previous = previous;
  }

  Node getNext(){
    return this.next;
  }

  Node getPrevious(){
    return this.previous;
  }
}
