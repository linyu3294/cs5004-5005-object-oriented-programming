package composite;

public interface IDepartment {
  void printDepartmentName();
}
