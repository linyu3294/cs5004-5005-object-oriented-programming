package composite;

public class SalesDepartment implements IDepartment {

  private Integer id;
  private String name;

  @Override
  public void printDepartmentName() {
    System.out.println(getClass().getSimpleName());
  }
}