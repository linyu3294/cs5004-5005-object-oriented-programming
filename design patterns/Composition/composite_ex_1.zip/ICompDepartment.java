package composite;

public interface ICompDepartment extends IDepartment {
  void addDepartment(IDepartment department);

  void removeDepartment(IDepartment department);
}
