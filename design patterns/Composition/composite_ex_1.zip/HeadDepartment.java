package composite;

import java.util.ArrayList;
import java.util.List;

public class HeadDepartment implements ICompDepartment {
  private Integer id;
  private String name;

  private List<IDepartment> childDepartments;

  public HeadDepartment(Integer id, String name) {
    this.id = id;
    this.name = name;
    this.childDepartments = new ArrayList<>();
  }

  @Override
  public void printDepartmentName() {
    childDepartments.forEach(IDepartment::printDepartmentName);
  }

  @Override
  public void addDepartment(IDepartment department) {
    childDepartments.add(department);
  }

  @Override
  public void removeDepartment(IDepartment department) {
    childDepartments.remove(department);
  }
}
