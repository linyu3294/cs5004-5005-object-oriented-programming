package composite;


public class FinancialDepartment implements IDepartment {

  private Integer id;
  private String name;

  @Override
  public void printDepartmentName() {
    System.out.println(getClass().getSimpleName());
  }

  // standard constructor, getters, setters
}

